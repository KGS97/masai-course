function PrivateRoute() {}

export default PrivateRoute;
